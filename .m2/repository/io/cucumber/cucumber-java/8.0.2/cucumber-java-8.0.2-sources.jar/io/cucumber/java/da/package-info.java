/**
 * Danish - dansk
 */
package io.cucumber.java.da;
