/**
 * Georgian - ქართული
 */
package io.cucumber.java.ka;
