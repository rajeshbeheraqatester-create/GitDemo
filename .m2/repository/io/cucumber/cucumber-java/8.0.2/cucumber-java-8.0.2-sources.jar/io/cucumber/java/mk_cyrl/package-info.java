/**
 * Macedonian - Македонски
 */
package io.cucumber.java.mk_cyrl;
