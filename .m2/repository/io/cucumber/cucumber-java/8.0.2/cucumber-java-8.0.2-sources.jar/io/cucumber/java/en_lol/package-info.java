/**
 * LOLCAT
 */
package io.cucumber.java.en_lol;
