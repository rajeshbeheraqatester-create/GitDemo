/**
 * Irish - Gaeilge
 */
package io.cucumber.java.ga;
