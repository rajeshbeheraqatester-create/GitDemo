/**
 * Hebrew - עברית
 */
package io.cucumber.java.he;
