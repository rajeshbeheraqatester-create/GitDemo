/**
 * Lithuanian - lietuvių kalba
 */
package io.cucumber.java.lt;
