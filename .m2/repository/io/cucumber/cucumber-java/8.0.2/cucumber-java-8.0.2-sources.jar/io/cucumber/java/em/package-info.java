/**
 * Emoji - 😀
 */
package io.cucumber.java.em;
