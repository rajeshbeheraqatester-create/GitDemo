/**
 * Indonesian - Bahasa Indonesia
 */
package io.cucumber.java.id;
