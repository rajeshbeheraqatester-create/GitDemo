/**
 * Gujarati - ગુજરાતી
 */
package io.cucumber.java.gj;
