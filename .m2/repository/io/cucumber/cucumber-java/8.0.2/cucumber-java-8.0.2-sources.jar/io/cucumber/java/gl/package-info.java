/**
 * Galician - galego
 */
package io.cucumber.java.gl;
