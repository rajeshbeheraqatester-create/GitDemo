/**
 * Catalan - català
 */
package io.cucumber.java.ca;
