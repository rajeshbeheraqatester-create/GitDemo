/**
 * Bulgarian - български
 */
package io.cucumber.java.bg;
