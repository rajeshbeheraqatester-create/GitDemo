/**
 * Japanese - 日本語
 */
package io.cucumber.java.ja;
