/**
 * Icelandic - Íslenska
 */
package io.cucumber.java.is;
