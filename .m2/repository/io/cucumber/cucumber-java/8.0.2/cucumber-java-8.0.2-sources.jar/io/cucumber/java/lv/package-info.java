/**
 * Latvian - latviešu
 */
package io.cucumber.java.lv;
