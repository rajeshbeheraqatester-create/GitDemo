/**
 * Korean - 한국어
 */
package io.cucumber.java.ko;
