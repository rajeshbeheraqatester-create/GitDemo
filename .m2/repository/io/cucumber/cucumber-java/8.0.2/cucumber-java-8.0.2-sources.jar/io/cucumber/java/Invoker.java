package io.cucumber.java;

import io.cucumber.core.backend.CucumberBackendException;
import io.cucumber.core.backend.CucumberInvocationTargetException;
import io.cucumber.core.backend.Located;
import org.jspecify.annotations.Nullable;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

final class Invoker {

    private Invoker() {

    }

    static @Nullable Object invoke(Annotation annotation, Method expressionMethod) {
        return invoke(null, annotation, expressionMethod);
    }

    static @Nullable Object invoke(@Nullable Located located, Object target, Method method, @Nullable Object... args) {
        Method targetMethod = targetMethod(target, method);
        return doInvoke(located, target, targetMethod, args);
    }

    private static Method targetMethod(Object target, Method method) {
        Class<?> targetClass = target.getClass();
        Class<?> declaringClass = method.getDeclaringClass();

        // Immediately return the provided method if the class loaders are the
        // same.
        if (targetClass.getClassLoader().equals(declaringClass.getClassLoader())) {
            return method;
        }

        try {
            // Check if the method is publicly accessible. Note that methods
            // from interfaces are always public.
            if (Modifier.isPublic(method.getModifiers())) {
                return targetClass.getMethod(method.getName(), method.getParameterTypes());
            }

            // Loop through all the super classes until the declared method is
            // found.
            Class<?> currentClass = targetClass;
            while (currentClass != Object.class) {
                try {
                    return currentClass.getDeclaredMethod(method.getName(), method.getParameterTypes());
                } catch (NoSuchMethodException e) {
                    currentClass = currentClass.getSuperclass();
                }
            }

            // The method does not exist in the class hierarchy.
            throw new NoSuchMethodException(String.valueOf(method));
        } catch (NoSuchMethodException e) {
            throw new CucumberBackendException("Could not find target method", e);
        }
    }

    @SuppressWarnings("deprecation") // isAccessible is deprecated in Java 9,
                                     // but canAccess not available on Android
    private static @Nullable Object doInvoke(
            @Nullable Located located, @Nullable Object target, Method targetMethod, @Nullable Object[] args
    ) {
        try {
            if (!targetMethod.isAccessible()) {
                targetMethod.setAccessible(true);
            }
            return targetMethod.invoke(target, args);
        } catch (IllegalArgumentException | IllegalAccessException e) {
            throw new CucumberBackendException("Failed to invoke " + targetMethod, e);
        } catch (InvocationTargetException e) {
            if (located == null) { // Reflecting into annotations
                throw new CucumberBackendException("Failed to invoke " + targetMethod, e);
            }
            if (e.getCause() == null) {
                throw new CucumberBackendException("Failed to invoke " + targetMethod, e);
            }
            throw new CucumberInvocationTargetException(located, e);
        }
    }

    static @Nullable Object invokeStatic(Located located, Method method, @Nullable Object... args) {
        return doInvoke(located, null, method, args);
    }

}
