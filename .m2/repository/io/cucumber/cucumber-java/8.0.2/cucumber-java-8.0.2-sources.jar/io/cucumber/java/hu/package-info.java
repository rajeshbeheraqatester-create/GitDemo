/**
 * Hungarian - magyar
 */
package io.cucumber.java.hu;
