/**
 * Kannada - ಕನ್ನಡ
 */
package io.cucumber.java.kn;
