/**
 * Aragonese - Aragonés
 */
package io.cucumber.java.an;
