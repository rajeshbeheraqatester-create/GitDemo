/**
 * Persian - فارسی
 */
package io.cucumber.java.fa;
