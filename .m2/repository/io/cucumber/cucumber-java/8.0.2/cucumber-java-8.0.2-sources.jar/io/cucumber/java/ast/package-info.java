/**
 * Asturian - asturianu
 */
package io.cucumber.java.ast;
