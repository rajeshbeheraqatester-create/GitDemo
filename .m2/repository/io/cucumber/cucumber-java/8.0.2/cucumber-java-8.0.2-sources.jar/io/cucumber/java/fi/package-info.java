/**
 * Finnish - suomi
 */
package io.cucumber.java.fi;
