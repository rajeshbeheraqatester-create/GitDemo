/**
 * Scouse
 */
package io.cucumber.java.en_scouse;
