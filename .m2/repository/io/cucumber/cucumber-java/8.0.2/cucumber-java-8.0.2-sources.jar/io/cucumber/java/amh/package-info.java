/**
 * Amharic - አማርኛ
 */
package io.cucumber.java.amh;
