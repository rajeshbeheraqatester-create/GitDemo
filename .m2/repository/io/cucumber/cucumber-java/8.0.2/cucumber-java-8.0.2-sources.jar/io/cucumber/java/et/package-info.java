/**
 * Estonian - eesti keel
 */
package io.cucumber.java.et;
