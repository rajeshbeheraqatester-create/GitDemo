/**
 * Arabic - العربية
 */
package io.cucumber.java.ar;
