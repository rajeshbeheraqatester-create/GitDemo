/**
 * Belarusian - Беларуская
 */
package io.cucumber.java.be;
