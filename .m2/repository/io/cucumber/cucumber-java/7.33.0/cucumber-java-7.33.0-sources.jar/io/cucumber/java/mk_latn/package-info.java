/**
 * Macedonian (Latin) - Makedonski (Latinica)
 */
package io.cucumber.java.mk_latn;
