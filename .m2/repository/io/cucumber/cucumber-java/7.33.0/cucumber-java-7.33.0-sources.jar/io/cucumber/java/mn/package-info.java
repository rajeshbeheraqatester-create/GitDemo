/**
 * Mongolian - монгол
 */
package io.cucumber.java.mn;
