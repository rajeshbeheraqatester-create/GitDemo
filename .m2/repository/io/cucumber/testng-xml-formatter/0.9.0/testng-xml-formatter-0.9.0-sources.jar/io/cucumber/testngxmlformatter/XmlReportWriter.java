package io.cucumber.testngxmlformatter;

import io.cucumber.messages.types.Exception;
import io.cucumber.messages.types.Feature;
import io.cucumber.messages.types.TestCaseStarted;
import io.cucumber.messages.types.TestRunHookFinished;
import io.cucumber.messages.types.TestStepResult;
import io.cucumber.messages.types.TestStepResultStatus;
import io.cucumber.testngxmlformatter.SourceReferenceFormatter.ClassMethodName;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import java.io.Writer;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;

import static io.cucumber.messages.types.TestStepResultStatus.PASSED;
import static io.cucumber.messages.types.TestStepResultStatus.SKIPPED;

class XmlReportWriter {
    private final XmlReportData data;

    XmlReportWriter(XmlReportData data) {
        this.data = data;
    }

    void writeXmlReport(Writer out) throws XMLStreamException {
        XMLOutputFactory factory = XMLOutputFactory.newInstance();
        EscapingXmlStreamWriter writer = new EscapingXmlStreamWriter(factory.createXMLStreamWriter(out));
        writer.writeStartDocument("UTF-8", "1.0");
        writer.writeNewLine();
        writeTestngResults(writer);
        writer.writeEndDocument();
        writer.flush();
    }

    private void writeTestngResults(EscapingXmlStreamWriter writer) throws XMLStreamException {
        writer.writeStartElement("testng-results");
        writeTestngResultsAttributes(writer);
        writer.writeNewLine();
        writeSuite(writer);
        writer.writeEndElement();
        writer.writeNewLine();
    }

    private void writeTestngResultsAttributes(EscapingXmlStreamWriter writer) throws XMLStreamException {
        Map<TestStepResultStatus, Long> counts = data.getTestCaseStatusCounts();

        writer.writeAttribute("failed", String.valueOf(countFailures(counts)));
        writer.writeAttribute("passed", String.valueOf(counts.get(PASSED)));
        writer.writeAttribute("skipped", String.valueOf(counts.get(SKIPPED)));
        writer.writeAttribute("total", String.valueOf(data.getTestCaseCount()));
    }

    private static long countFailures(Map<TestStepResultStatus, Long> counts) {
        return createNotPassedNotSkippedSet().stream().mapToLong(counts::get).sum();
    }

    private static Set<TestStepResultStatus> createNotPassedNotSkippedSet() {
        EnumSet<TestStepResultStatus> notPassedNotSkipped = EnumSet.allOf(TestStepResultStatus.class);
        notPassedNotSkipped.remove(PASSED);
        notPassedNotSkipped.remove(SKIPPED);
        return notPassedNotSkipped;
    }


    private void writeSuite(EscapingXmlStreamWriter writer) throws XMLStreamException {
        writer.writeStartElement("suite");
        writeSuiteAttributes(writer);
        writer.writeNewLine();
        writeTest(writer);
        writer.writeEndElement();
        writer.writeNewLine();
    }

    private void writeSuiteAttributes(EscapingXmlStreamWriter writer) throws XMLStreamException {
        writer.writeAttribute("name", "Cucumber");
        writer.writeAttribute("duration-ms", String.valueOf(data.getSuiteDurationInMilliSeconds()));
    }

    private void writeTest(EscapingXmlStreamWriter writer) throws XMLStreamException {
        writer.writeStartElement("test");
        writeTestAttributes(writer);
        writer.writeNewLine();

        for (var nonPassingHooksByClassName : data.getAllNonPassingTestRunHooksFinished().entrySet()) {
            var className = nonPassingHooksByClassName.getKey();
            var nonPassingTestRunHooks = nonPassingHooksByClassName.getValue();

            writer.writeStartElement("class");
            writer.writeAttribute("name", className.orElse("Unknown"));
            writer.writeNewLine();

            for (var nonPassingHooksByClassMethodName : nonPassingTestRunHooks) {
                writeSyntheticTestMethod(writer, nonPassingHooksByClassMethodName.getKey(), nonPassingHooksByClassMethodName.getValue());
            }
            writer.writeEndElement();
            writer.writeNewLine();
        }

        Set<Entry<Optional<Feature>, List<TestCaseStarted>>> allTestCaseStartedGroupedByFeature = data.getAllTestCaseStartedGroupedByFeature();
        for (Entry<Optional<Feature>, List<TestCaseStarted>> entry : allTestCaseStartedGroupedByFeature) {
            writer.writeStartElement("class");
            String featureName = entry.getKey()
                    .map(Feature::getName)
                    .orElse("Unknown");
            writer.writeAttribute("name", featureName);
            writer.writeNewLine();

            for (TestCaseStarted testCaseStarted : entry.getValue()) {
                writeTestMethod(writer, testCaseStarted);
            }
            writer.writeEndElement();
            writer.writeNewLine();
        }
        writer.writeEndElement();
        writer.writeNewLine();
    }

    private void writeTestAttributes(EscapingXmlStreamWriter writer) throws XMLStreamException {
        writer.writeAttribute("name", "Cucumber");
        writer.writeAttribute("duration-ms", String.valueOf(data.getSuiteDurationInMilliSeconds()));
    }

    private void writeSyntheticTestMethod(EscapingXmlStreamWriter writer, ClassMethodName classMethodName, TestRunHookFinished testRunHookFinished) throws XMLStreamException {
        TestStepResult result = testRunHookFinished.getResult();
        boolean passing = isPassed(result);
        if (passing) {
            writer.writeEmptyElement("test-method");
        } else {
            writer.writeStartElement("test-method");
        }
        writeSyntheticTestMethodAttributes(writer, classMethodName, testRunHookFinished, result);
        if (!passing) {
            writer.writeNewLine();
            writeSyntheticException(writer, result);
            writer.writeEndElement();
        }
        writer.writeNewLine();
    }

    private void writeSyntheticTestMethodAttributes(EscapingXmlStreamWriter writer, ClassMethodName classMethodName, TestRunHookFinished testRunHookFinished, TestStepResult result) throws XMLStreamException {
        writer.writeAttribute("name", classMethodName.methodName());
        writer.writeAttribute("status", writeStatus(result));
        writer.writeAttribute("duration-ms", String.valueOf(data.getDurationInMilliSeconds(testRunHookFinished)));
        writer.writeAttribute("started-at", data.getStartedAt(testRunHookFinished));
        writer.writeAttribute("finished-at", data.getFinishedAt(testRunHookFinished));
    }

    private void writeSyntheticException(EscapingXmlStreamWriter writer, TestStepResult result) throws XMLStreamException {
        if (result.getException().isEmpty()) {
            return;
        }
        Exception exceptionOrSkippedOrUndefined = result.getException().get();
        Optional<String> stackTrace = exceptionOrSkippedOrUndefined.getStackTrace();
        writer.writeStartElement("exception");
        writeExceptionAttributes(writer, exceptionOrSkippedOrUndefined);
        writer.writeNewLine();

        if (stackTrace.isPresent()) {
            writer.writeStartElement("full-stacktrace");
            writer.writeNewLine();
            writer.writeCData(stackTrace.get());
            writer.writeNewLine();
            writer.writeEndElement();
            writer.writeNewLine();
        }
        writer.writeEndElement();
        writer.writeNewLine();
    }

    private void writeTestMethod(EscapingXmlStreamWriter writer, TestCaseStarted testCaseStarted) throws XMLStreamException {
        TestStepResult result = data.getTestCaseStatus(testCaseStarted);

        boolean passing = isPassed(result);
        if (passing) {
            writer.writeEmptyElement("test-method");
        } else {
            writer.writeStartElement("test-method");
        }
        writeTestMethodAttributes(writer, testCaseStarted, result);
        if (!passing) {
            writer.writeNewLine();
            writeException(writer, testCaseStarted, result);
            writer.writeEndElement();
        }
        writer.writeNewLine();
    }

    private static boolean isPassed(TestStepResult result) {
        TestStepResultStatus status = result.getStatus();
        return status == PASSED;
    }

    private void writeTestMethodAttributes(EscapingXmlStreamWriter writer, TestCaseStarted testCaseStarted, TestStepResult result) throws XMLStreamException {
        writer.writeAttribute("name", data.getPickleName(testCaseStarted));
        writer.writeAttribute("status", writeStatus(result));
        writer.writeAttribute("duration-ms", String.valueOf(data.getDurationInMilliSeconds(testCaseStarted)));
        writer.writeAttribute("started-at", data.getStartedAt(testCaseStarted));
        writer.writeAttribute("finished-at", data.getFinishedAt(testCaseStarted));
    }

    private String writeStatus(TestStepResult status) {
        return switch (status.getStatus()) {
            case PASSED -> "PASS";
            case SKIPPED -> "SKIP";
            default -> "FAIL";
        };
    }

    private void writeException(EscapingXmlStreamWriter writer, TestCaseStarted testCaseStarted, TestStepResult result) throws XMLStreamException {
        Exception exceptionOrSkippedOrUndefined = result.getException()
                .orElseGet(nonPassingStepsException(result.getStatus()));
        Optional<String> stackTrace = exceptionOrSkippedOrUndefined.getStackTrace();
        writer.writeStartElement("exception");
        writeExceptionAttributes(writer, exceptionOrSkippedOrUndefined);
        writer.writeNewLine();

        writeMessage(writer, testCaseStarted);

        if (stackTrace.isPresent()) {
            writer.writeStartElement("full-stacktrace");
            writer.writeNewLine();
            writer.writeCData(stackTrace.get());
            writer.writeNewLine();

            writer.writeEndElement();
            writer.writeNewLine();
        }
        writer.writeEndElement();
        writer.writeNewLine();

    }



    private static Supplier<Exception> nonPassingStepsException(TestStepResultStatus status) {
        return switch (status) {
            // Skipped may not be caused by an exception, i.e. `return "skipped` in JS or Ruby.
            case SKIPPED ->
                    () -> new Exception(
                            "The scenario has skipped step(s)",
                            null,
                            "The scenario has skipped step(s)"
                    );
            // Skipped may not be caused by an exception, i.e. `return "pending` in JS or Ruby.
            case PENDING -> () -> new Exception(
                    "The scenario has pending step(s)",
                    null,
                    "The scenario has pending step(s)"
            );
            // Undefined is never caused by an exception
            case UNDEFINED -> () -> new Exception(
                    "The scenario has undefined step(s)",
                    null,
                    "The scenario has undefined step(s)"
            );
            // Ambiguous doesn't have to come with an exception.
            case AMBIGUOUS -> () -> new Exception(
                    "The scenario has ambiguous step(s)",
                    null,
                    "The scenario has ambiguous step(s)"
            );
            default -> () -> new Exception(
                    "The scenario has non-passing step(s)",
                    null,
                    "The scenario has non-passing step(s)"
            );
        };
    }

    private void writeExceptionAttributes(EscapingXmlStreamWriter writer, Exception exception) throws XMLStreamException {
        writer.writeAttribute("class", exception.getType());
    }

    private void writeMessage(EscapingXmlStreamWriter writer, TestCaseStarted testCaseStarted) throws XMLStreamException {
        List<Entry<String, String>> results = data.getStepsAndResult(testCaseStarted);
        if (results.isEmpty()) {
            return;
        }
        writer.writeStartElement("message");
        writer.writeCData(createStepResultList(results));
        writer.writeEndElement();
        writer.writeNewLine();
    }

    private String createStepResultList(List<Entry<String, String>> results) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        results.forEach(r -> {
            String stepText = r.getKey();
            String status = r.getValue();
            sb.append(stepText);
            sb.append(".");
            sb.append(".".repeat(Math.max(0, 75 - stepText.length())));
            sb.append(status);
            sb.append("\n");
        });
        return sb.toString();
    }
}
