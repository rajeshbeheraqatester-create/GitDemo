package io.cucumber.testng;

import io.cucumber.plugin.Plugin;
import org.apiguardian.api.API;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Configure Cucumbers options.
 *
 * @deprecated Since v3.6.0 Maven Surefire uses the JUnit Platform to run
 *             TestNG. Cucumber support the JUnit Platform directly. Since
 *             v9.4.0 Gradle supports resource based test on the JUnit Platform.
 *             This leaves little reason to support a dedicated TestNG runner.
 *             <p>
 *             Please switch to <a href=
 *             "https://github.com/cucumber/cucumber-jvm/tree/main/cucumber-junit-platform-engine">cucumber-junit-platform-engine</a>.
 *             If there are missing features that prevent you from upgrading
 *             please create an issue.
 */
@Deprecated(forRemoval = true)
@API(status = API.Status.DEPRECATED)
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface CucumberOptions {

    /**
     * Return true if glue code execution should be skipped.
     *
     * @return true if glue code execution should be skipped.
     */
    boolean dryRun() default false;

    /**
     * A list of features paths.
     * <p>
     * A feature path is constructed as
     * {@code  [ PATH[.feature[:LINE]*] | URI[.feature[:LINE]*] | @PATH ] }
     * <p>
     * Examples:
     * <ul>
     * <li>{@code src/test/resources/features} -- All features in the
     * {@code src/test/resources/features} directory</li>
     * <li>{@code classpath:com/example/application} -- All features in the
     * {@code com.example.application} package</li>
     * <li>{@code in-memory:/features} -- All features in the {@code /features}
     * directory on an in memory file system supported by
     * {@link java.nio.file.FileSystems}</li>
     * <li>{@code src/test/resources/features/example.feature:42} -- The
     * scenario or example at line 42 in the example feature file</li>
     * <li>{@code @target/rerun} -- All the scenarios in the files in the rerun
     * directory</li>
     * <li>{@code @target/rerun/RunCucumber.txt} -- All the scenarios in
     * RunCucumber.txt file</li>
     * </ul>
     * <p>
     * When no feature path is provided, Cucumber will use the package of the
     * annotated class. For example, if the annotated class is
     * {@code com.example.RunCucumber} then features are assumed to be located
     * in {@code classpath:com/example}.
     *
     * @return list of files or directories
     * @see    io.cucumber.core.feature.FeatureWithLines
     */
    String[] features() default {};

    /**
     * Package to load glue code (step definitions, hooks and plugins) from.
     * E.g: {@code com.example.app}
     * <p>
     * When no glue is provided, Cucumber will use the package of the annotated
     * class. For example, if the annotated class is
     * {@code com.example.RunCucumber} then glue is assumed to be located in
     * {@code com.example}.
     *
     * @return list of package names
     * @see    io.cucumber.core.feature.GluePath
     */
    String[] glue() default {};

    /**
     * Classes with glue code.
     * <p>
     * When no glue is provided, Cucumber will use the package of the annotated
     * class. For example, if the annotated class is
     * {@code com.example.RunCucumber} then glue is assumed to be located in
     * {@code com.example}.
     *
     * @return list of class names
     */
    Class<?>[] glueClasses() default {};

    /**
     * Package to load additional glue code (step definitions, hooks and
     * plugins) from. E.g: {@code com.example.app}
     * <p>
     * These packages are used in addition to the default described in
     * {@link #glue()}.
     *
     * @return list of package names
     */
    String[] extraGlue() default {};

    /**
     * Additional classes with glue code.
     * <p>
     * These classes are used in addition to the default described in
     * {@code #glue}.
     * <p>
     * Classes that explicitly listed as glue are not filtered by either
     * {@link #includedGlueClassNamePatterns()} or
     * {@link #excludedGlueClassNamePatterns()}.
     *
     * @return list of class names
     */
    Class<?>[] extraGlueClasses() default {};

    /**
     * The pattern for included glue classes.
     * <p>
     * A glue class is included in classpath scanning if the include pattern
     * matches it and the exclude pattern doesn't.
     * <p>
     * Example: {@code .*StepDefinitions?|.*Hooks?}
     *
     * @return list of patterns
     */
    String[] includedGlueClassNamePatterns() default {};

    /**
     * The pattern for excluded glue classes.
     * <p>
     * A glue class is included in classpath scanning if the include pattern
     * matches it and the exclude pattern doesn't.
     * <p>
     * Example: {@code .*UnwantedStepDefinitions?|.*UnwantedHooks?}
     *
     * @return list of patterns
     */
    String[] excludedGlueClassNamePatterns() default {};

    /**
     * Only run scenarios tagged with tags matching
     * <a href="https://github.com/cucumber/tag-expressions">Tag Expression</a>.
     * <p>
     * For example {@code "@smoke and not @fast"}.
     *
     * @return a tag expression
     */
    String tags() default "";

    /**
     * Register plugins. Built-in plugin types: {@code junit}, {@code html},
     * {@code pretty}, {@code progress}, {@code json}, {@code usage},
     * {@code unused}, {@code rerun}, {@code testng}.
     * <p>
     * Can also be a fully qualified class name, allowing registration of 3rd
     * party plugins.
     * <p>
     * Plugins can be provided with an argument. For example
     * {@code json:target/cucumber-report.json}
     *
     * @return list of plugins
     * @see    Plugin
     */
    String[] plugin() default {};

    /**
     * Publish report to
     * <a href="https://reports.cucumber.io">reports.cucumber.io</a>.
     *
     * @return true if reports should be published on the web.
     */
    boolean publish() default false;

    /**
     * Returns true if terminal output should be without colours.
     *
     * @return true if terminal output should be without colours.
     */
    boolean monochrome() default false;

    /**
     * Only run scenarios whose names match one of the provided regular
     * expressions.
     *
     * @return a list of regular expressions
     */
    String[] name() default {};

    /**
     * Returns the format of the generated snippets.
     *
     * @return the format of the generated snippets.
     */
    SnippetType snippets() default SnippetType.UNDERSCORE;

    /**
     * Specify a custom ObjectFactory.
     * <p>
     * In case a custom ObjectFactory is needed, the class can be specified
     * here. A custom ObjectFactory might be needed when more granular control
     * is needed over the dependency injection mechanism.
     *
     * @return an {@link io.cucumber.core.backend.ObjectFactory} implementation
     */
    Class<? extends io.cucumber.core.backend.ObjectFactory> objectFactory() default NoObjectFactory.class;

    /**
     * Specify a custom ObjectFactory.
     * <p>
     * In case a custom ObjectFactory is needed, the class can be specified
     * here. A custom ObjectFactory might be needed when more granular control
     * is needed over the dependency injection mechanism.
     *
     * @return an {@link io.cucumber.core.backend.ObjectFactory} implementation
     */
    Class<? extends io.cucumber.core.eventbus.UuidGenerator> uuidGenerator() default NoUuidGenerator.class;

    enum SnippetType {
        UNDERSCORE, CAMELCASE
    }

}
