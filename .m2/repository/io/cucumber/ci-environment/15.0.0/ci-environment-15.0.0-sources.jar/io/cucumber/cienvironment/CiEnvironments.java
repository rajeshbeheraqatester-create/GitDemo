package io.cucumber.cienvironment;

import java.util.Collection;

import static java.util.Arrays.asList;

final class CiEnvironments {
    static final Collection<CiEnvironmentImpl> TEMPLATES = asList(
            new CiEnvironmentImpl(
                    "Azure Pipelines",
                    "${BUILD_BUILDURI}",
                    "${BUILD_BUILDNUMBER}",
                    new CiEnvironmentImpl.Git(
                            "${BUILD_REPOSITORY_URI}",
                            "${BUILD_SOURCEVERSION}",
                            "${BUILD_SOURCEBRANCH/refs/heads/(.*)/\\1}",
                            "${BUILD_SOURCEBRANCH/refs/tags/(.*)/\\1}")),
            new CiEnvironmentImpl(
                    "Bamboo",
                    "${bamboo_buildResultsUrl}",
                    "${bamboo_buildNumber}",
                    new CiEnvironmentImpl.Git(
                            "${bamboo_planRepository_repositoryUrl}",
                            "${bamboo_planRepository_revision}",
                            "${bamboo_planRepository_branch}",
                            null)),
            new CiEnvironmentImpl(
                    "Buddy",
                    "${BUDDY_EXECUTION_URL}",
                    "${BUDDY_EXECUTION_ID}",
                    new CiEnvironmentImpl.Git(
                            "${BUDDY_SCM_URL}",
                            "${BUDDY_EXECUTION_REVISION}",
                            "${BUDDY_EXECUTION_BRANCH}",
                            "${BUDDY_EXECUTION_TAG}")),
            new CiEnvironmentImpl(
                    "Bitrise",
                    "${BITRISE_BUILD_URL}",
                    "${BITRISE_BUILD_NUMBER}",
                    new CiEnvironmentImpl.Git(
                            "${GIT_REPOSITORY_URL}",
                            "${BITRISE_GIT_COMMIT}",
                            "${BITRISE_GIT_BRANCH}",
                            "${BITRISE_GIT_TAG}")),
            new CiEnvironmentImpl(
                    "CircleCI",
                    "${CIRCLE_BUILD_URL}",
                    "${CIRCLE_BUILD_NUM}",
                    new CiEnvironmentImpl.Git(
                            "${CIRCLE_REPOSITORY_URL}",
                            "${CIRCLE_SHA1}",
                            "${CIRCLE_BRANCH}",
                            "${CIRCLE_TAG}")),
            new CiEnvironmentImpl(
                    "CodeFresh",
                    "${CF_BUILD_URL}",
                    "${CF_BUILD_ID}",
                    new CiEnvironmentImpl.Git(
                            "${CF_COMMIT_URL/(.*)\\/commit.+$/\\1}.git",
                            "${CF_REVISION}",
                            "${CF_BRANCH}",
                            null)),
            new CiEnvironmentImpl(
                    "CodeShip",
                    "${CI_BUILD_URL}",
                    "${CI_BUILD_NUMBER}",
                    new CiEnvironmentImpl.Git(
                            "${CI_PULL_REQUEST/(.*)\\/pull\\/\\d+/\\1.git}",
                            "${CI_COMMIT_ID}",
                            "${CI_BRANCH}",
                            null)),
            new CiEnvironmentImpl(
                    "GitHub Actions",
                    "${GITHUB_SERVER_URL}/${GITHUB_REPOSITORY}/actions/runs/${GITHUB_RUN_ID}",
                    "${GITHUB_RUN_ID}",
                    new CiEnvironmentImpl.Git(
                            "${GITHUB_SERVER_URL}/${GITHUB_REPOSITORY}.git",
                            "${GITHUB_SHA}",
                            "${GITHUB_HEAD_REF}",
                            "${GITHUB_REF/refs/tags/(.*)/\\1}")),
            new CiEnvironmentImpl(
                    "GitLab",
                    "${CI_JOB_URL}",
                    "${CI_JOB_ID}",
                    new CiEnvironmentImpl.Git(
                            "${CI_REPOSITORY_URL}",
                            "${CI_COMMIT_SHA}",
                            "${CI_COMMIT_BRANCH}",
                            "${CI_COMMIT_TAG}")),
            new CiEnvironmentImpl(
                    "GoCD",
                    "${GO_SERVER_URL}/pipelines/${GO_PIPELINE_NAME}/${GO_PIPELINE_COUNTER}/${GO_STAGE_NAME}/${GO_STAGE_COUNTER}",
                    "${GO_PIPELINE_NAME}/${GO_PIPELINE_COUNTER}/${GO_STAGE_NAME}/${GO_STAGE_COUNTER}",
                    new CiEnvironmentImpl.Git(
                            "${GO_SCM_*_PR_URL/(.*)\\/pull\\/\\d+/\\1.git}",
                            "${GO_REVISION}",
                            "${GO_SCM_*_PR_BRANCH/.*:(.*)/\\1}",
                            null)),
            new CiEnvironmentImpl(
                    "Jenkins",
                    "${BUILD_URL}",
                    "${BUILD_NUMBER}",
                    new CiEnvironmentImpl.Git(
                            "${GIT_URL}",
                            "${GIT_COMMIT}",
                            "${GIT_LOCAL_BRANCH}",
                            null)),
            new CiEnvironmentImpl(
                    "JetBrains Space",
                    "${JB_SPACE_EXECUTION_URL}",
                    "${JB_SPACE_EXECUTION_NUMBER}",
                    new CiEnvironmentImpl.Git(
                            "https://${JB_SPACE_API_URL}/p/${JB_SPACE_PROJECT_KEY}/repositories/${JB_SPACE_GIT_REPOSITORY_NAME}",
                            "${JB_SPACE_GIT_REVISION}",
                            "${JB_SPACE_GIT_BRANCH}",
                            null)),
            new CiEnvironmentImpl(
                    "Semaphore",
                    "${SEMAPHORE_ORGANIZATION_URL}/jobs/${SEMAPHORE_JOB_ID}",
                    "${SEMAPHORE_JOB_ID}",
                    new CiEnvironmentImpl.Git(
                            "${SEMAPHORE_GIT_URL}",
                            "${SEMAPHORE_GIT_SHA}",
                            "${SEMAPHORE_GIT_BRANCH}",
                            "${SEMAPHORE_GIT_TAG_NAME}")),
            new CiEnvironmentImpl(
                    "Travis CI",
                    "${TRAVIS_BUILD_WEB_URL}",
                    "${TRAVIS_JOB_NUMBER}",
                    new CiEnvironmentImpl.Git(
                            "https://github.com/${TRAVIS_REPO_SLUG}.git",
                            "${TRAVIS_COMMIT}",
                            "${TRAVIS_BRANCH}",
                            "${TRAVIS_TAG}")),
            new CiEnvironmentImpl(
                    "Wercker",
                    "${WERCKER_RUN_URL}",
                    "${WERCKER_RUN_URL/.*\\/([^\\/]+)$/\\1}",
                    new CiEnvironmentImpl.Git(
                            "https://${WERCKER_GIT_DOMAIN}/${WERCKER_GIT_OWNER}/${WERCKER_GIT_REPOSITORY}.git",
                            "${WERCKER_GIT_COMMIT}",
                            "${WERCKER_GIT_BRANCH}",
                            null))
    );

    private CiEnvironments(){
        /* no-op */
    }
}
