package io.cucumber.core.backend;

import io.cucumber.core.backend.discovery.GlueDiscoveryRequest;
import io.cucumber.core.backend.discovery.UriGlueDiscoverySelector;
import org.apiguardian.api.API;
import org.jspecify.annotations.Nullable;

import java.net.URI;
import java.util.List;

@API(status = API.Status.STABLE)
public interface Backend {

    /**
     * Invoked once before all features. This is where steps and hooks should be
     * loaded.
     *
     * @param glue    Glue that provides the steps to be executed.
     * @param request A request to discover glue code in specific locations.
     */
    @API(status = API.Status.EXPERIMENTAL, since = "8.0.0")
    default void loadGlue(Glue glue, GlueDiscoveryRequest request) {
        var gluePaths = request.getSelectorsByType(UriGlueDiscoverySelector.class) //
                .stream() //
                .map(UriGlueDiscoverySelector::uri) //
                .toList();
        loadGlue(glue, gluePaths);
    }

    /**
     * Invoked once before all features. This is where steps and hooks should be
     * loaded.
     *
     * @param      glue      Glue that provides the steps to be executed.
     * @param      gluePaths The locations for the glue to be loaded.
     * @deprecated           use {@link #loadGlue(Glue, GlueDiscoveryRequest)}
     *                       instead.
     */
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "8.0.0")
    default void loadGlue(Glue glue, List<URI> gluePaths) {

    }

    /**
     * Invoked before a new scenario starts. Implementations should do any
     * necessary setup of new, isolated state here. Additional scenario scoped
     * step definitions can be loaded here. These step definitions should
     * implement {@link ScenarioScoped}
     */
    default void buildWorld() {

    }

    /**
     * Invoked at the end of a scenario, after hooks
     */
    default void disposeWorld() {

    }

    @Nullable
    default Snippet getSnippet() {
        return null;
    }

}
