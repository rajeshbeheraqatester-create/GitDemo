package io.cucumber.core.runtime;

import io.cucumber.core.eventbus.EventBus;
import io.cucumber.core.gherkin.Feature;
import io.cucumber.core.logging.Logger;
import io.cucumber.core.logging.LoggerFactory;
import io.cucumber.core.runner.Runner;
import io.cucumber.messages.ProtocolVersion;
import io.cucumber.messages.types.Ci;
import io.cucumber.messages.types.Envelope;
import io.cucumber.messages.types.Git;
import io.cucumber.messages.types.Meta;
import io.cucumber.messages.types.Product;
import io.cucumber.plugin.event.Result;
import io.cucumber.plugin.event.Status;
import io.cucumber.plugin.event.TestRunFinished;
import io.cucumber.plugin.event.TestRunStarted;
import io.cucumber.plugin.event.TestSourceParsed;
import io.cucumber.plugin.event.TestSourceRead;
import org.jspecify.annotations.Nullable;

import java.time.Duration;
import java.time.Instant;
import java.util.ResourceBundle;
import java.util.UUID;
import java.util.function.Consumer;

import static io.cucumber.cienvironment.DetectCiEnvironment.detectCiEnvironment;
import static io.cucumber.core.exception.ExceptionUtils.throwAsUncheckedException;
import static io.cucumber.messages.Convertor.toMessage;
import static java.util.Collections.singletonList;
import static java.util.Objects.requireNonNull;

public final class CucumberExecutionContext {

    private static final String VERSION = ResourceBundle.getBundle("io.cucumber.core.version")
            .getString("cucumber-jvm.version");
    private static final Logger log = LoggerFactory.getLogger(CucumberExecutionContext.class);

    private final EventBus bus;
    private final ExitStatus exitStatus;
    private final RunnerSupplier runnerSupplier;
    private final RethrowingThrowableCollector collector = new RethrowingThrowableCollector();
    private @Nullable Instant start;
    private @Nullable UUID testRunStartedId;

    public CucumberExecutionContext(EventBus bus, ExitStatus exitStatus, RunnerSupplier runnerSupplier) {
        this.bus = bus;
        this.exitStatus = exitStatus;
        this.runnerSupplier = runnerSupplier;
    }

    public void startTestRun() {
        emitMeta();
        emitTestRunStarted();
    }

    private void emitMeta() {
        bus.send(Envelope.of(createMeta()));
    }

    private Meta createMeta() {
        return new Meta(
            ProtocolVersion.getVersion(),
            new Product("cucumber-jvm", VERSION),
            new Product(System.getProperty("java.vm.name"), System.getProperty("java.vm.version")),
            new Product(System.getProperty("os.name"), System.getProperty("os.version")),
            new Product(System.getProperty("os.arch"), null),
            detectCiEnvironment(System.getenv()).map(ci -> new Ci(
                ci.getName(),
                ci.getUrl(),
                ci.getBuildNumber().orElse(null),
                ci.getGit().map(git -> new Git(
                    git.getRemote(),
                    git.getRevision(),
                    git.getBranch().orElse(null),
                    git.getTag().orElse(null)))
                        .orElse(null)))
                    .orElse(null));
    }

    private void emitTestRunStarted() {
        log.debug(() -> "Sending run test started event");
        start = bus.getInstant();
        testRunStartedId = bus.generateId();
        bus.send(new TestRunStarted(start));
        bus.send(
            Envelope.of(new io.cucumber.messages.types.TestRunStarted(toMessage(start), testRunStartedId.toString())));
    }

    public void runBeforeAllHooks() {
        Runner runner = getRunner();
        var hookException = collector
                .executeAndThrow(() -> runner.runBeforeAllHooks(requireNonNull(testRunStartedId).toString()));
        if (hookException != null) {
            throw throwAsUncheckedException(hookException);
        }
    }

    public void runAfterAllHooks() {
        Runner runner = getRunner();
        var hookException = collector
                .executeAndThrow(() -> runner.runAfterAllHooks(requireNonNull(testRunStartedId).toString()));
        if (hookException != null) {
            throw throwAsUncheckedException(hookException);
        }
    }

    public void finishTestRun() {
        log.debug(() -> "Sending test run finished event");
        Throwable cucumberException = getThrowable();
        emitTestRunFinished(cucumberException);
    }

    public @Nullable Throwable getThrowable() {
        return collector.getThrowable();
    }

    private void emitTestRunFinished(@Nullable Throwable exception) {
        Instant instant = bus.getInstant();
        Result result = new Result(
            exception != null ? Status.FAILED : exitStatus.getStatus(),
            Duration.between(requireNonNull(start), instant),
            exception);
        bus.send(new TestRunFinished(instant, result));

        io.cucumber.messages.types.TestRunFinished testRunFinished = new io.cucumber.messages.types.TestRunFinished(
            exception != null ? exception.getMessage() : null,
            exception == null && exitStatus.isSuccess(),
            toMessage(instant),
            exception == null ? null : toMessage(exception),
            requireNonNull(testRunStartedId).toString());
        bus.send(Envelope.of(testRunFinished));
    }

    public void beforeFeature(Feature feature) {
        log.debug(() -> "Sending test source read event for " + feature.getUri());
        collector.executeAndThrow(() -> {
            bus.send(new TestSourceRead(bus.getInstant(), feature.getUri(), feature.getSource()));
            bus.send(new TestSourceParsed(bus.getInstant(), feature.getUri(), singletonList(feature)));
            bus.sendAll(feature.getParseEvents());
        });
    }

    public void runTestCase(Consumer<Runner> execution) {
        Runner runner = getRunner();
        runner.setTestRunStartedId(testRunStartedId);
        try {
            collector.executeAndThrow(() -> execution.accept(runner));
        } finally {
            runner.setTestRunStartedId(null);
        }
    }

    private Runner getRunner() {
        return collector.executeAndThrow(runnerSupplier::get);
    }

}
