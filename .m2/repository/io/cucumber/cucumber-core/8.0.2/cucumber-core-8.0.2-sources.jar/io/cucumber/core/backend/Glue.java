package io.cucumber.core.backend;

import org.apiguardian.api.API;

/**
 * A container of glue code.
 * <p>
 * Glue code connects steps in files to executable code. It also includes
 * before-, after-, each and all hooks, parameter types, data table types and
 * docstrings.
 * <p>
 * Glue is provided by a {@link Backend} implementation which discovers it on
 * request.
 */
@API(status = API.Status.STABLE)
public interface Glue {

    void addBeforeAllHook(StaticHookDefinition beforeAllHook);

    void addAfterAllHook(StaticHookDefinition afterAllHook);

    void addStepDefinition(StepDefinition stepDefinition);

    void addBeforeHook(HookDefinition beforeHook);

    void addAfterHook(HookDefinition afterHook);

    void addBeforeStepHook(HookDefinition beforeStepHook);

    void addAfterStepHook(HookDefinition afterStepHook);

    void addParameterType(ParameterTypeDefinition parameterType);

    void addDataTableType(DataTableTypeDefinition dataTableType);

    void addDefaultParameterTransformer(DefaultParameterTransformerDefinition defaultParameterTransformer);

    void addDefaultDataTableEntryTransformer(
            DefaultDataTableEntryTransformerDefinition defaultDataTableEntryTransformer
    );

    void addDefaultDataTableCellTransformer(DefaultDataTableCellTransformerDefinition defaultDataTableCellTransformer);

    void addDocStringType(DocStringTypeDefinition docStringType);

}
