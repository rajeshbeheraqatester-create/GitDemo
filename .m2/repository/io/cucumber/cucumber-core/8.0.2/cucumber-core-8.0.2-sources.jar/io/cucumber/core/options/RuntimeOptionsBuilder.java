package io.cucumber.core.options;

import io.cucumber.core.backend.ObjectFactory;
import io.cucumber.core.eventbus.UuidGenerator;
import io.cucumber.core.exception.CucumberException;
import io.cucumber.core.feature.FeatureWithLines;
import io.cucumber.core.order.PickleOrder;
import io.cucumber.core.plugin.Options;
import io.cucumber.core.snippets.SnippetType;
import io.cucumber.tagexpressions.Expression;
import org.jspecify.annotations.Nullable;

import java.net.URI;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

public final class RuntimeOptionsBuilder {

    private final List<Expression> parsedTagFilters = new ArrayList<>();
    private final List<Pattern> parsedNameFilters = new ArrayList<>();
    private final List<FeatureWithLines> parsedFeaturePaths = new ArrayList<>();
    private final List<URI> parsedGlue = new ArrayList<>();
    private final Set<String> parsedGlueClasses = new HashSet<>();
    private final List<Options.Plugin> plugins = new ArrayList<>();
    private @Nullable List<FeatureWithLines> parsedRerunPaths = null;
    private @Nullable Integer parsedThreads = null;
    private @Nullable Boolean parsedDryRun = null;
    private @Nullable Boolean parsedMonochrome = null;
    private @Nullable SnippetType parsedSnippetType = null;
    private @Nullable Boolean parsedWip = null;
    private @Nullable Boolean parsedGlueHint = null;
    private @Nullable Duration parsedGlueHintThreshold = null;
    private @Nullable PickleOrder parsedPickleOrder = null;
    private @Nullable Integer parsedCount = null;
    private @Nullable Class<? extends ObjectFactory> parsedObjectFactoryClass = null;
    private @Nullable Class<? extends UuidGenerator> parsedUuidGeneratorClass = null;
    private @Nullable Boolean addDefaultSummaryPrinter = null;
    private boolean addDefaultGlueIfAbsent;
    private boolean addDefaultFeaturePathIfAbsent;
    private @Nullable String parsedPublishToken = null;
    private @Nullable Boolean parsedPublish;
    private @Nullable Boolean parsedPublishQuiet;
    private @Nullable Boolean parsedEnablePublishPlugin;
    private List<Pattern> glueIncludedClassNamePatterns = new ArrayList<>();
    private List<Pattern> glueExcludedClassNamePatterns = new ArrayList<>();

    public RuntimeOptionsBuilder addRerun(Collection<FeatureWithLines> featureWithLines) {
        if (parsedRerunPaths == null) {
            parsedRerunPaths = new ArrayList<>();
        }
        parsedRerunPaths.addAll(featureWithLines);
        return this;
    }

    public RuntimeOptionsBuilder addFeature(FeatureWithLines featureWithLines) {
        parsedFeaturePaths.add(featureWithLines);
        return this;
    }

    public RuntimeOptionsBuilder addGlue(URI glue) {
        parsedGlue.add(glue);
        return this;
    }

    public RuntimeOptionsBuilder addGlueClass(String glueClassName) {
        parsedGlueClasses.add(glueClassName);
        return this;
    }

    public RuntimeOptionsBuilder addNameFilter(Pattern pattern) {
        this.parsedNameFilters.add(pattern);
        return this;
    }

    public RuntimeOptionsBuilder addPluginName(String pluginSpecification) {
        PluginOption pluginOption = PluginOption.parse(pluginSpecification);
        if (pluginOption.isEventListener()) {
            plugins.add(pluginOption);
        } else {
            throw new CucumberException("Unrecognized plugin: " + pluginSpecification);
        }
        return this;
    }

    public RuntimeOptionsBuilder addTagFilter(Expression tagExpression) {
        this.parsedTagFilters.add(tagExpression);
        return this;
    }

    public RuntimeOptions build() {
        return build(RuntimeOptions.defaultOptions());
    }

    public RuntimeOptions build(RuntimeOptions runtimeOptions) {
        if (this.parsedThreads != null) {
            runtimeOptions.setThreads(this.parsedThreads);
        }

        if (this.parsedDryRun != null) {
            runtimeOptions.setDryRun(this.parsedDryRun);
        }

        if (this.parsedMonochrome != null) {
            runtimeOptions.setMonochrome(this.parsedMonochrome);
        }

        if (this.parsedSnippetType != null) {
            runtimeOptions.setSnippetType(this.parsedSnippetType);
        }

        if (this.parsedWip != null) {
            runtimeOptions.setWip(this.parsedWip);
        }

        if (this.parsedGlueHint != null) {
            runtimeOptions.setGlueHintEnabled(this.parsedGlueHint);
        }

        if (this.parsedGlueHintThreshold != null) {
            runtimeOptions.setGlueHintThreshold(this.parsedGlueHintThreshold);
        }

        if (this.parsedPickleOrder != null) {
            runtimeOptions.setPickleOrder(this.parsedPickleOrder);
        }

        if (this.parsedCount != null) {
            runtimeOptions.setCount(this.parsedCount);
        }

        if (!this.parsedTagFilters.isEmpty() || !this.parsedNameFilters.isEmpty() || hasFeaturesWithLineFilters()) {
            runtimeOptions.setTagExpressions(this.parsedTagFilters);
            runtimeOptions.setNameFilters(this.parsedNameFilters);
        }
        if (!this.parsedFeaturePaths.isEmpty() || this.parsedRerunPaths != null) {
            List<FeatureWithLines> features = new ArrayList<>(this.parsedFeaturePaths);
            if (parsedRerunPaths != null) {
                features.addAll(this.parsedRerunPaths);
            }
            runtimeOptions.setFeaturePaths(features);
        }

        if (!this.parsedGlue.isEmpty()) {
            runtimeOptions.setGlue(this.parsedGlue);
        }

        if (!this.parsedGlueClasses.isEmpty()) {
            runtimeOptions.setGlueClasses(this.parsedGlueClasses);
        }

        runtimeOptions.addPlugins(this.plugins);

        if (parsedObjectFactoryClass != null) {
            runtimeOptions.setObjectFactoryClass(parsedObjectFactoryClass);
        }

        if (parsedUuidGeneratorClass != null) {
            runtimeOptions.setUuidGeneratorClass(parsedUuidGeneratorClass);
        }

        if (addDefaultSummaryPrinter != null && addDefaultSummaryPrinter) {
            runtimeOptions.addDefaultSummaryPrinter();
        }

        if (addDefaultGlueIfAbsent) {
            runtimeOptions.addDefaultGlueIfAbsent();
        }

        if (addDefaultFeaturePathIfAbsent) {
            runtimeOptions.addDefaultFeaturePathIfAbsent();
        }

        if (parsedPublishToken != null) {
            runtimeOptions.setPublishToken(parsedPublishToken);
        }

        if (parsedPublish != null) {
            runtimeOptions.setPublish(parsedPublish);
        }

        if (parsedPublishQuiet != null) {
            runtimeOptions.setPublishQuiet(parsedPublishQuiet);
        }

        if (parsedEnablePublishPlugin != null) {
            runtimeOptions.setEnablePublishPlugin(parsedEnablePublishPlugin);
        }

        if (!glueIncludedClassNamePatterns.isEmpty()) {
            runtimeOptions.setGlueIncludedClassNamePatterns(glueIncludedClassNamePatterns);
        }
        if (!glueExcludedClassNamePatterns.isEmpty()) {
            runtimeOptions.setGlueExcludedClassNamePatterns(glueExcludedClassNamePatterns);
        }

        return runtimeOptions;
    }

    private boolean hasFeaturesWithLineFilters() {
        return parsedRerunPaths != null || !parsedFeaturePaths.stream()
                .map(FeatureWithLines::lines)
                .allMatch(Set::isEmpty);
    }

    public RuntimeOptionsBuilder setCount(int count) {
        this.parsedCount = count;
        return this;
    }

    public RuntimeOptionsBuilder setDryRun() {
        return setDryRun(true);
    }

    public RuntimeOptionsBuilder setDryRun(boolean dryRun) {
        this.parsedDryRun = dryRun;
        return this;
    }

    public RuntimeOptionsBuilder setMonochrome() {
        return setMonochrome(true);
    }

    public RuntimeOptionsBuilder setMonochrome(boolean monochrome) {
        this.parsedMonochrome = monochrome;
        return this;
    }

    public RuntimeOptionsBuilder setPickleOrder(PickleOrder pickleOrder) {
        this.parsedPickleOrder = pickleOrder;
        return this;
    }

    public RuntimeOptionsBuilder setSnippetType(SnippetType snippetType) {
        this.parsedSnippetType = snippetType;
        return this;
    }

    public RuntimeOptionsBuilder setThreads(int threads) {
        this.parsedThreads = threads;
        return this;
    }

    public RuntimeOptionsBuilder setWip(boolean wip) {
        this.parsedWip = wip;
        return this;
    }

    public RuntimeOptionsBuilder setGlueHintEnabled(boolean glueHint) {
        this.parsedGlueHint = glueHint;
        return this;
    }

    public RuntimeOptionsBuilder setGlueHintThreshold(Duration threshold) {
        this.parsedGlueHintThreshold = threshold;
        return this;
    }

    public RuntimeOptionsBuilder setNoSummary() {
        this.addDefaultSummaryPrinter = false;
        return this;
    }

    public RuntimeOptionsBuilder addDefaultSummaryPrinterIfNotDisabled() {
        if (this.addDefaultSummaryPrinter == null) {
            this.addDefaultSummaryPrinter = true;
        }
        return this;
    }

    public RuntimeOptionsBuilder addDefaultGlueIfAbsent() {
        this.addDefaultGlueIfAbsent = true;
        return this;
    }

    public RuntimeOptionsBuilder addDefaultFeaturePathIfAbsent() {
        this.addDefaultFeaturePathIfAbsent = true;
        return this;
    }

    public RuntimeOptionsBuilder setObjectFactoryClass(Class<? extends ObjectFactory> objectFactoryClass) {
        this.parsedObjectFactoryClass = objectFactoryClass;
        return this;
    }

    public RuntimeOptionsBuilder setUuidGeneratorClass(Class<? extends UuidGenerator> uuidGeneratorClass) {
        this.parsedUuidGeneratorClass = uuidGeneratorClass;
        return this;
    }

    public RuntimeOptionsBuilder setPublishToken(String token) {
        this.parsedPublishToken = token;
        return this;
    }

    public RuntimeOptionsBuilder setPublish(boolean publish) {
        this.parsedPublish = publish;
        return this;
    }

    public RuntimeOptionsBuilder setPublishQuiet(boolean publishQuiet) {
        this.parsedPublishQuiet = publishQuiet;
        return this;
    }

    public RuntimeOptionsBuilder enablePublishPlugin() {
        this.parsedEnablePublishPlugin = true;
        return this;
    }

    public void addGlueIncludedClassNamePattern(Pattern pattern) {
        this.glueIncludedClassNamePatterns.add(pattern);
    }

    public void addGlueExcludedClassNamePattern(Pattern pattern) {
        this.glueExcludedClassNamePatterns.add(pattern);
    }
}
