package io.cucumber.core.options;

import org.jspecify.annotations.Nullable;

final class BooleanString {

    private BooleanString() {
        /* no-op */
    }

    static boolean parseBoolean(@Nullable String s) {
        if (s == null) {
            return false;
        }

        if ("true".equalsIgnoreCase(s)) {
            return true;
        } else if ("false".equalsIgnoreCase(s)) {
            return false;
        }

        if ("1".equalsIgnoreCase(s)) {
            return true;
        } else if ("0".equalsIgnoreCase(s)) {
            return false;
        }

        if ("yes".equalsIgnoreCase(s)) {
            return true;
        } else if ("no".equalsIgnoreCase(s)) {
            return false;
        }

        throw new IllegalArgumentException(
            "'%s' Was not a valid boolean value. Please use either 'true' or 'false'.".formatted(s));
    }
}
