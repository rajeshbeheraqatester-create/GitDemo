package io.cucumber.datatable;

import org.apiguardian.api.API;
import org.jspecify.annotations.Nullable;

import java.lang.reflect.Type;

import static io.cucumber.datatable.TypeFactory.typeName;

@API(status = API.Status.STABLE)
public class CucumberDataTableException extends RuntimeException {
    CucumberDataTableException(String message) {
        super(message);
    }

    CucumberDataTableException(@Nullable String message, Throwable throwable) {
        super(message, throwable);
    }

    static CucumberDataTableException cantConvertTo(Type type, String message) {
        return new CucumberDataTableException(
            "Can't convert DataTable to %s. %s".formatted(typeName(type), message));
    }

    private static CucumberDataTableException cantConvertToMap(Type keyType, Type valueType, String message) {
        return new CucumberDataTableException(
            "Can't convert DataTable to Map<%s, %s>.\n%s".formatted(typeName(keyType), typeName(valueType), message));
    }

    static <K, V> CucumberDataTableException duplicateKeyException(
            Type keyType, Type valueType, @Nullable K key, @Nullable V value, @Nullable V replaced
    ) {
        return cantConvertToMap(keyType, valueType,
            "Encountered duplicate key %s with values %s and %s".formatted(key, replaced, value));
    }

    static CucumberDataTableException keyValueMismatchException(
            boolean firstHeaderCellIsBlank, int keySize, Type keyType, int valueSize, Type valueType
    ) {
        if (keySize > valueSize) {
            return cantConvertToMap(keyType, valueType,
                "There are more keys than values. " +
                        "Did you use a TableEntryTransformer for the value while using a TableRow or TableCellTransformer for the keys?");
        }

        if (valueSize % keySize == 0) {
            return cantConvertToMap(keyType, valueType,
                ("There is more then one value per key. " +
                        "Did you mean to transform to Map<%s, List<%s>> instead?")
                        .formatted(typeName(keyType), typeName(valueType)));
        }

        if (firstHeaderCellIsBlank) {
            return cantConvertToMap(keyType, valueType,
                "There are more values then keys. The first header cell was left blank. You can add a value there");
        }

        return cantConvertToMap(keyType, valueType,
            "There are more values then keys. " +
                    "Did you use a TableEntryTransformer for the key while using a TableRow or TableCellTransformer for the value?");
    }

    static CucumberDataTableException keysImplyTableEntryTransformer(Type keyType, Type valueType) {
        return cantConvertToMap(keyType, valueType,
            """
                    The first cell was either blank or you have registered a TableEntryTransformer for the key type.

                    This requires that there is a TableEntryTransformer for the value type but I couldn't find any.

                    You can either:

                      1) Use a DataTableType that uses a TableEntryTransformer for %s

                      2) Add a key to the first cell and use a DataTableType that uses a TableEntryTransformer for %s"""
                    .formatted(valueType, keyType));
    }

}
