package io.cucumber.messages.types;

import io.cucumber.messages.Property;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static java.util.Objects.requireNonNull;

/**
 * Represents the TestCase message in <a href=https://github.com/cucumber/messages>Cucumber's message protocol</a>
 * <p>
 * A `TestCase` contains a sequence of `TestStep`s.
 */
// Generated code
@SuppressWarnings({"unused", "JavaLangClash"})
public final class TestCase {
    private final String id;
    private final String pickleId;
    private final List<TestStep> testSteps;
    private final @Nullable String testRunStartedId;

    public TestCase(
        @Property("id") String id,
        @Property("pickleId") String pickleId,
        @Property("testSteps") List<TestStep> testSteps,
        @Nullable @Property("testRunStartedId") String testRunStartedId
    ) {
        this.id = requireNonNull(id, "TestCase.id cannot be null");
        this.pickleId = requireNonNull(pickleId, "TestCase.pickleId cannot be null");
        this.testSteps = List.copyOf(requireNonNull(testSteps, "TestCase.testSteps cannot be null"));
        this.testRunStartedId = testRunStartedId;
    }

    public String getId() {
        return id;
    }

    /**
     * The ID of the `Pickle` this `TestCase` is derived from.
     */
    public String getPickleId() {
        return pickleId;
    }

    public List<TestStep> getTestSteps() {
        return testSteps;
    }

    /**
     * Identifier for the test run that this test case belongs to
     */
    public Optional<String> getTestRunStartedId() {
        return Optional.ofNullable(testRunStartedId);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TestCase that = (TestCase) o;
        return 
            id.equals(that.id) &&         
            pickleId.equals(that.pickleId) &&         
            testSteps.equals(that.testSteps) &&         
            Objects.equals(testRunStartedId, that.testRunStartedId);        
    }

    @Override
    public int hashCode() {
        return Objects.hash(
            id,
            pickleId,
            testSteps,
            testRunStartedId
        );
    }

    @Override
    public String toString() {
        return "TestCase{" +
            "id=" + id +
            ", pickleId=" + pickleId +
            ", testSteps=" + testSteps +
            ", testRunStartedId=" + testRunStartedId +
            '}';
    }
}
