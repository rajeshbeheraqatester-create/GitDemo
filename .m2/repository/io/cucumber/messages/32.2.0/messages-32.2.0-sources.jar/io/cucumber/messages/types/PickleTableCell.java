package io.cucumber.messages.types;

import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static java.util.Objects.requireNonNull;

/**
 * Represents the PickleTableCell message in <a href=https://github.com/cucumber/messages>Cucumber's message protocol</a>
 */
// Generated code
@SuppressWarnings({"unused", "JavaLangClash"})
public final class PickleTableCell {
    private final String value;

    public PickleTableCell(
        String value
    ) {
        this.value = requireNonNull(value, "PickleTableCell.value cannot be null");
    }

    public String getValue() {
        return value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PickleTableCell that = (PickleTableCell) o;
        return 
            value.equals(that.value);        
    }

    @Override
    public int hashCode() {
        return Objects.hash(
            value
        );
    }

    @Override
    public String toString() {
        return "PickleTableCell{" +
            "value=" + value +
            '}';
    }
}
