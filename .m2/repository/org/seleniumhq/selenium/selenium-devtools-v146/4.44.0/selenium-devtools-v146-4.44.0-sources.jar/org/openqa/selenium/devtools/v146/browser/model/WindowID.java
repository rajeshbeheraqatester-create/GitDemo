package org.openqa.selenium.devtools.v146.browser.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class WindowID {

    private final java.lang.Integer windowID;

    public WindowID(java.lang.Integer windowID) {
        this.windowID = java.util.Objects.requireNonNull(windowID, "Missing value for WindowID");
    }

    private static WindowID fromJson(JsonInput input) {
        return new WindowID(input.nextNumber().intValue());
    }

    public Integer toJson() {
        return windowID;
    }

    public String toString() {
        return windowID.toString();
    }
}
