package org.openqa.selenium.devtools.v146.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public enum PartitioningBlobURLInfo {

    BLOCKEDCROSSPARTITIONFETCHING("BlockedCrossPartitionFetching"), ENFORCENOOPENERFORNAVIGATION("EnforceNoopenerForNavigation");

    private String value;

    PartitioningBlobURLInfo(String value) {
        this.value = value;
    }

    public static PartitioningBlobURLInfo fromString(String s) {
        return java.util.Arrays.stream(PartitioningBlobURLInfo.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within PartitioningBlobURLInfo "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static PartitioningBlobURLInfo fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
